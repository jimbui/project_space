﻿using UnityEngine;
using System.Collections;

public class Camera2 : MonoBehaviour {
	public Transform myTarget;

	// Use this for initialization
	void Start () {
	
	}
	
	// Update is called once per frame
	void Update () {
	Vector3 targPos = myTarget.position;
	targPos.z = transform.position.z;
	//set the new z to be the old z because if we dont, the z will change to the new target, and the camera would be too close.
	//vector 3 allows us to change z. z is the rotation.
	transform.position = targPos;
	}
}
