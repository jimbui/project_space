﻿using UnityEngine;
using System.Collections;

public class FPSloop : MonoBehaviour {
	
	public int max = 10;
	public GameObject enemyShip;
	int x;
	int i;


	// Use this for initialization
	void Start ()
	{
		for (i = 0; i < max; i++) {
			x = i * 2;
			Instantiate (enemyShip, new Vector3 (x, 0, 0), Quaternion.identity);
		}
	}
	// Update is called once per frame
	void Update () {

		x= i+1;
	}

	}
