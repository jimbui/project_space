﻿using UnityEngine;
using System.Collections;

public class Turning : MonoBehaviour {
	Transform player;
	public float rotspeed = 90f;
	// Update is called once per frame
	void Update () {
		if (player == null) {
			GameObject go = GameObject.Find ("player");
			print ("finding");

			if (go != null) {
				player = go.transform;
				print ("found");
			}

			if (player == null) {
				return;
			}
		}

		Vector3 direction = player.position - transform.position;
		direction.Normalize();

		float zAngle = Mathf.Atan2(direction.y,direction.x) * Mathf.Rad2Deg - 90;
		//returns a radian which then get turn to degree, to show direction angle)
		//this assumes that 0 is o the x axis, we add 90 to ajust that to y.
		//in math a 0 angle faces the right. we want it to face up.

		Quaternion desiredRot = transform.rotation = Quaternion.Euler (0,0, zAngle);
		Quaternion.RotateTowards(transform.rotation, desiredRot, rotspeed * Time.deltaTime);
		//rotate from our location to desired location by 90 degrees per sec. 
	}
}
