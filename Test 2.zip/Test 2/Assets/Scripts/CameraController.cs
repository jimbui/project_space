﻿using UnityEngine;
using System.Collections;

public class CameraController : MonoBehaviour {
	public GameObject player;
	//this creates a box to drag the player into so we can refer to it.

	private Vector3 offset;

	// Use this for initialization
	void Start () {
	 offset = transform.position - player.transform.position;
	 //this is refering to the transform of the object this is attached to.
	}
	
	// Update is called once per frame
	void LateUpdate () {
	//late update runs last. and we make sure the player has already run
	transform.position = player.transform.position + offset;
	}
}
