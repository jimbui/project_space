﻿using UnityEngine;
using System.Collections;

public class ColDmg : MonoBehaviour {

	int health = 1;

	void OnTriggerEnter2D ()
	{
		print ("trigger");
		health--;
		}

	void Update ()
	{
		if (health <= 0) {
			Die ();
		}
	}
	void Die() {
	Destroy(gameObject);
}
}
