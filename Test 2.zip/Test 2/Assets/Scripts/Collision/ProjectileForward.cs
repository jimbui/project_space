﻿using UnityEngine;
using System.Collections;

public class ProjectileForward : MonoBehaviour {
public float maxSpeed = 5f;
	// Use this for initialization
	void Start () {
	
	}
	
	// Update is called once per frame
	void Update () {
	Vector3 pos = transform.position;
	Vector3 velocity = new Vector3(0, maxSpeed * Time.deltaTime, 0);

	pos = pos + (transform.rotation * velocity); 
	//quat has to go first. this will translate the object relative to the velocity

	transform.position = pos;
	//transform position to pos
	}
}
