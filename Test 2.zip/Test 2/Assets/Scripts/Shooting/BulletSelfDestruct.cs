﻿using UnityEngine;
using System.Collections;

public class BulletSelfDestruct : MonoBehaviour 
{
	void OnEnable () 
	{
			Invoke ("Destroy", 2f);
			// print ("moved");
	}

	void Destroy()
	{
		gameObject.SetActive(false);
	}

	void OnDisable() 
	{
			CancelInvoke();
			// prevents call from turning false then true in the same frame.
	}
}