﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;
//generic gives us a list to store things.

public class Enemyshooting : MonoBehaviour {
	float cooldownTimer = 0;
	public float fireDelay = 0.25f;
	public GameObject bullet;
	public GameObject gun;

	public int poolAmount = 10;
	List<GameObject> bullets;








	void Start () {
	bullets = new List<GameObject>();
		for (int i = 0; i < poolAmount; i++) {
			GameObject obj = (GameObject)Instantiate(bullet);
			obj.layer = gameObject.layer;
			obj.SetActive(false);
			bullets.Add(obj);
		}
	}
	
	// Update is called once per frame
	void Update () {

	cooldownTimer -=Time.deltaTime;



	if (cooldownTimer <= 0)

	{
			//cooldownTimer <= 0
			cooldownTimer = fireDelay;

			for (int i = 0; i < bullets.Count; i++) {
				if(!bullets[i].activeInHierarchy) {
					bullets[i].transform.position = gun.transform.position;
					bullets[i].transform.rotation = gun.transform.rotation;
					bullets[i].SetActive(true);
					break;
		//if bullet is not active in the list.
			}

	}
}
}
}
