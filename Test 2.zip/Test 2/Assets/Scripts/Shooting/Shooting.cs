﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;
//generic gives us a list to store things.

public class Shooting : MonoBehaviour 
{
	float cooldownTimer = 0;
	public float fireDelay = 0.25f;
	public GameObject bullet;
	public GameObject gun;
	public int poolAmount = 10;
	List<GameObject> bullets;
	int bullet_rotation = 0 ;

	void Start () 
	{
		bullets = new List<GameObject>();
		for (int i = 0; i < poolAmount; i++) {
			GameObject obj = (GameObject)Instantiate(bullet);
			obj.layer = gameObject.layer;
			obj.SetActive(false);
			bullets.Add(obj);
		}
	}
	
	// Update is called once per frame
	void Update () 
	{
		cooldownTimer -=Time.deltaTime;
		//remove time spent since last frame.
		if (Input.GetButton("Fire1") && cooldownTimer <= 0)
		{
			cooldownTimer = fireDelay;
			/*
			for (int i = 0; i < bullets.Count; i++) 
			{
				if(!bullets[i].activeInHierarchy) 
				{
					bullets[i].transform.position = gun.transform.position;
					bullets[i].transform.rotation = gun.transform.rotation;
					bullets[i].SetActive(true);
					break;
					//if bullet is not active in the list.
				}
			}
			*/

				bullets[bullet_rotation].transform.position = gun.transform.position;
				bullets[bullet_rotation].transform.rotation = gun.transform.rotation;
				bullets[bullet_rotation].SetActive(true);

			bullet_rotation++ ;
			if (bullet_rotation == bullets.Count) bullet_rotation = 0 ;
		}
	}
}
