﻿using UnityEngine;
using System.Collections;

public class Mouse3 : MonoBehaviour {
private Vector3 target; 
private float currentAngle;
private Vector3 direction;
private float checkAngle;
private float ang;
private float turnang;
private float movingTurn;
private float turnAngleUp;
private float turnAngleDown;
private bool turning = false;
private float turnForwardSpeed = 1;

	// Use this for initialization
	void Start () {
	
	}



	
	// Update is called once per frame
	void Update ()
	{


		if (Input.GetMouseButtonDown (0)) {

			TurnandMoveForward ();
		}


		if (transform.eulerAngles.z > 180f) {
			currentAngle = transform.eulerAngles.z - 360; 
		} else {
			currentAngle = transform.eulerAngles.z;
		}

		if (!(currentAngle <= turnAngleUp && currentAngle >= turnAngleDown)) {
			//if (currentAngle != turnang) {
			movingTurn += 1;
			transform.eulerAngles = new Vector3 (0, 0, movingTurn);
			//transform.position += (transform.forward * turnforwardSpeed * Time.deltaTime);
			turning = true;
		} else {
			turning = false;
		}


		if (turning) {

		Vector3 velocity = new Vector3(0, turnForwardSpeed * Time.deltaTime, 0);

		}




	}

	void TurnandMoveForward ()
	{

		target = Camera.main.ScreenToWorldPoint (Input.mousePosition);
		direction = target - transform.position;


		ang = Mathf.Atan2 (direction.x, direction.y) * Mathf.Rad2Deg;
		turnang = ang * -1;

		print ("current angle: " + currentAngle);
		print ("direction angle: " + turnang);

		turnAngleUp = turnang + 1;
		turnAngleDown = turnang - 1;





		}

			}