﻿using UnityEngine;
using System.Collections;

public class Mouse4 : MonoBehaviour {
	private Vector3 target;
    private Vector3 direction;
    private float zAngle;
    private float rotturn;
    private float i;
    private float zAngle3;
	// Update is called once per frame

	void Start ()
	{
		zAngle = 0;
	}


	void Update ()
	{

		if (Input.GetMouseButton (0)) {
			target = Camera.main.ScreenToWorldPoint (Input.mousePosition);
			//change target to mouse position.
			target.z = transform.position.z;
			i = 1;
		}

		Vector3 direction = target - transform.position;
		direction.Normalize ();

		zAngle = Mathf.Atan2 (direction.y, direction.x) * Mathf.Rad2Deg - 90;
		float zAngle2 = zAngle / 10;

		while (i <= 10 && i > 0) {
			
			zAngle3 = zAngle2 * i;
			transform.rotation = (Quaternion.Euler (0, 0, zAngle3));
			print (i);
			i++;
			if (zAngle3 == zAngle) {
				i = 0;
				print ("finished");
			}
		}
	}



}

