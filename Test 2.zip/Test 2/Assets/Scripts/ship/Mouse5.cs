﻿using System.Collections;
using UnityEngine;

public class Mouse5 : MonoBehaviour {
	private Vector3 target;
    private Vector3 direction;
	// Update is called once per frame

	void Start ()
	{
	}


	void Update ()
	{



		if (Input.GetMouseButton (0)) {
			target = Camera.main.ScreenToWorldPoint (Input.mousePosition);
			//change target to mouse position.
			target.z = transform.position.z;


}
}
}
