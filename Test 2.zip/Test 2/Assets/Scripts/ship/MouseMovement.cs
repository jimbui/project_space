﻿using UnityEngine;
using System.Collections;

public class MouseMovement : MonoBehaviour {
 
    public float speed = 1;
    private Vector3 target;
    private Vector3 direction;

    void Start () {
         target = transform.position;
     }

     
    void Update ()
	{



		if (Input.GetMouseButtonDown (0)) {
			target = Camera.main.ScreenToWorldPoint (Input.mousePosition);
			target.z = transform.position.z;

			direction = target - transform.position;

			transform.rotation = Quaternion.LookRotation (Vector3.forward, direction);
		}

         transform.position = Vector3.MoveTowards(transform.position, target, speed * Time.deltaTime);


     }    
 }
