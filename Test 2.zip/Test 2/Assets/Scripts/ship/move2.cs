﻿using UnityEngine;
using System.Collections;

public class move2 : MonoBehaviour {
	// Use this for initialization

	float maxSpeed = 3.5f;
	float rotSpeed = 180f;
	//degree in a second
	//all vectors use floats.


	void Start () {
	
	}
	
	// Update is called once per frame
	void Update () {
	//rotate the ship
	Quaternion rot = transform.rotation;
	//grabs the rotation quaternion
	float z = rot.eulerAngles.z;
	//euler angels is the xyz of angles.super confusing no one gets it.

	z-= Input.GetAxis ("Horizontal") * rotSpeed * Time.deltaTime;
	//change z angle based on input

	rot = Quaternion.Euler(0,0,z);
	//recreate the quaternion

	transform.rotation = rot;
	//feed quaternion into rotation.




	Vector3 pos = transform.position;
	//needs to create a Vector 3 named pos to store position.
	//pos.y += Input.GetAxis("Vertical");
	//current position plus input.
	//pos.y += Input.GetAxis("Vertical") * maxSpeed * Time.deltaTime;
	Vector3 velocity = new Vector3(0,Input.GetAxis("Vertical") * maxSpeed * Time.deltaTime, 0);

	pos = pos + (rot * velocity); 
	//quat has to go first. this will translate the object relative to the velocity

	transform.position = pos;
	//transform position to pos
	}
}
