﻿using UnityEngine;
using System.Collections;

public class test : MonoBehaviour {

	// Use this for initialization
	void Start () {
	Invoke("DoSomething", 5);
	}

	void DoSomething ()
	{

		print ("doing");
	}
	
	// Update is called once per frame
	void Update () {


	
	}
}
